import { Link } from "react-router-dom"

const Menu = () => {
  return (
    <ul>
      <li><Link to="/practice1">Practice1</Link></li>
      <li><Link to="/practice2">Practice2</Link></li>
      <li><Link to="/practice3">Practice3</Link></li>
      <li><Link to="/practice4">Practice4</Link></li>
      <li><Link to="/homework3">Homework3</Link></li>
      <li><Link to="/homework4">Homework4</Link></li>
      <li><Link to="/homework5">Homework5</Link></li>
      <li><Link to="/homework6">Homework6</Link></li>
    </ul>
  )
}

export default Menu