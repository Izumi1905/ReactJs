import React from 'react'

class Practice4 extends React.Component {
  constructor() {
    super()

    this.state = {
      inputValue: "",
      isLoggedIn: false
    }
  }

  changeInput = (e) => {
    this.setState({
      ...this.state,
      inputValue: e.target.value
    })
  }

  login = () => {
    this.setState({
      ...this.state,
      isLoggedIn: true
    })
  }

  render() {
    const { inputValue, isLoggedIn } = this.state

    if (isLoggedIn) {
      return <Home user={inputValue} />
    }
    return (
      <>
        <h1>Please login</h1>
        <div><input type="text" value={inputValue} onChange={this.changeInput} /></div>
        <button onClick={this.login}>Login</button>
      </>
    )
  }
}

class Home extends React.Component {

  render() {
    const { user } = this.props
    return (
      <h2>Welcome: {user}</h2>
    )
  }
}

export default Practice4