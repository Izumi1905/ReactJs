import './Homework5.module.css'

import React from 'react'

class Homework5 extends React.Component {
  constructor() {
    super()
    this.state = {
      form: {
        name: "",
        phone: "",
        email: ""
      },
      students: [],
    }
  }

  resetForm = () => {
    return {
      name: "",
      phone: "",
      email: ""
    }
  }

  handleChange = (e) => {
    this.setState(prevState => {
      const { form } = prevState
      form[e.target.name] = e.target.value
      return { form }
    })
  }

  handleSubmitForm = () => {

    this.setState(prevState => {
      const { students, form: { name, phone, email } } = prevState
      const isFormValid = name && phone && email
      if (!isFormValid) {
        return;
      }
      students.push({ name, phone, email })
      return { students, form: this.resetForm() }
    })

  }

  editStudent = (student) => {
    const form = {}
    form.name = student.name
    form.email = student.email
    form.phone = student.phone
    this.setState({form})
  }

  deleteStudent = (selectedStudent) => {
    this.setState(prevState => {
      const { students } = prevState
      const remainingStudents = students.filter(student => student.email !== selectedStudent.email)
      return { students: remainingStudents }
    })
  }

  render() {
    const { form, students } = this.state
    return (
      <div>
        <div>
          <h1>Student List</h1>
          <div>
            <label>Name: </label>
            <input name="name" onChange={this.handleChange} value={form.name} />
          </div>
          <div>
            <label>Phone: </label>
            <input type="number" name="phone" onChange={this.handleChange} value={form.phone} />
          </div>
          <div>
            <label>Email: </label>
            <input name="email" onChange={this.handleChange} value={form.email} />
          </div>
          <button onClick={this.handleSubmitForm}>Submit</button>
          <table>
            <thead>
              <tr>
                <td>Name</td>
                <td>Phone</td>
                <td>Email</td>
                <td>Action</td>
              </tr>
            </thead>
            <tbody>
              {students.map(student => (
                <tr key={student.email}>
                  <td>{student.name}</td>
                  <td>{student.phone}</td>
                  <td>{student.email}</td>
                  <td>
                    <button onClick={() => this.editStudent(student)}>Edit</button>
                    <button onClick={() => this.deleteStudent(student)}>Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    )
  }
}

export default Homework5