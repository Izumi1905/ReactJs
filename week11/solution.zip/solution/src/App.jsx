import {
  RouterProvider,
  createBrowserRouter,
} from "react-router-dom";

import Homework3 from "./Homework3";
import Homework4 from "./Homework4";
import Homework5 from "./Homework5";
import Menu from "./Menu";
import Practice1 from "./Practice1";
import Practice2 from "./Practice2";
import Practice3 from "./Practice3";
import Practice4 from "./Practice4";
import React from 'react'
import Homework6 from "./Homework6";

const router = createBrowserRouter([
  {
    path: '/practice1',
    element: <Practice1 />
  },
  {
    path: '/practice2',
    element: <Practice2 />
  },
  {
    path: '/practice3',
    element: <Practice3 />
  },
  {
    path: '/practice4',
    element: <Practice4 />
  },
  {
    path: '/homework3',
    element: <Homework3 />
  },
  {
    path: '/homework4',
    element: <Homework4 />
  },
  {
    path: '/homework5',
    element: <Homework5 />
  },
  {
    path: '/homework6',
    element: <Homework6 />
  },
  {
    path: '/',
    element: <Menu />
  }
])


class App extends React.Component {

  render() {
    return (
      <RouterProvider router={router} />
    )
  }
}

export default App
