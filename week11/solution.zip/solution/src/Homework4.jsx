import React from 'react'

class Homework4 extends React.Component {
  constructor() {
    super()
    this.state = {
      todos: [],
      inputField: ''
    }
  }

  handleInputChange = (e) => {
    this.setState(prevState => {
      let { inputField } = prevState
      inputField = e.target.value
      return { inputField }
    })
  }

  addNewTodo = () => {
    this.setState(prevState => {
      const { todos, inputField } = prevState
      todos.push(inputField)
      return { todos }
    })
  }

  render() {
    const { inputField, todos } = this.state
    return (
      <>
        <h2>Todo List</h2>
        <input type="text" value={inputField} onChange={this.handleInputChange} />
        <button onClick={this.addNewTodo}>Add</button>
        <RenderList todos={todos} />
      </>
    )
  }
}

class RenderList extends React.Component {
  render() {
    return (
      <ul>
        {this.props.todos.map(todo => <li key={todo}>{todo}</li>)}
      </ul>
    )
  }
}

export default Homework4