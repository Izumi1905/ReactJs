import 'bootstrap/dist/css/bootstrap.min.css'
import './Homework3.css'

import React from 'react'

class LoggedIn extends React.Component {
  render() {
    return (
      <div className="container d-flex align-items-center text-center">
        <div className="form-signin">
          <h1 className="h3 mb-3 fw-normal">Welcome {this.props.email}</h1>
          <button className="w-100 btn btn-lg btn-primary" type="button" onClick={this.props.onLogOut}>Log out</button>
        </div>
      </div>
    )
  }
}

class Homework3 extends React.Component {
  constructor() {
    super()
    this.state = {
      form: {
        email: '',
        password: '',
        isRemember: false
      },
      isValid: false,
      isLoggedIn: false
    }
  }

  handleChange = (e) => {
    this.setState(prevState => {
      const { form } = prevState
      form[e.target.name] = e.target.value
      return { form }
    }, this.checkValidDetail)
  }

  handleChangeCheckbox = () => {
    this.setState(prevState => {
      const { form } = prevState
      form.isRemember = !form.isRemember
      return { form }
    }, this.checkValidDetail)
  }

  checkValidDetail = () => {
    const { email, password } = this.state.form
    const isValid = email && password
    this.setState({
      isValid
    })
  }

  handleSubmit = () => {
    if (this.state.isValid) {
      this.setState({
        isLoggedIn: true
      })
    }
  }

  handleLogout = () => {
    this.setState({
      isLoggedIn: false
    })
  }

  render() {
    const { form } = this.state

    if (this.state.isLoggedIn) {
      return <LoggedIn onLogOut={this.handleLogout} email={form.email} />
    }

    return (
      <div className="container d-flex align-items-center text-center">
        <div className="form-signin">
          <form>
            <img className="mb-4" src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/b2/Bootstrap_logo.svg/2560px-Bootstrap_logo.svg.png" alt="" width="72" height="57" />
            <h1 className="h3 mb-3 fw-normal">Please sign in</h1>
            <div className="form-floating">
              <input className="form-control email" type="email" name="email" placeholder="name@example.com" value={form.email} onChange={this.handleChange} />
              <label>Email address</label>
            </div>
            <div className="form-floating">
              <input className="form-control password" type="password" name="password" placeholder="Password" value={form.password} onChange={this.handleChange} />
              <label>Password</label>
            </div>
            <div className="checkbox mb-3">
              <label>
                <input type="checkbox" value={form.isRemember} onChange={this.handleChangeCheckbox} /> Remember me
              </label>
            </div>
            <button className="w-100 btn btn-lg btn-primary" type="button" onClick={this.handleSubmit} >Sign in</button>
            <p className="mt-5 mb-3 text-muted">© 2017–2021</p>
          </form>
        </div>
      </div>
    )
  }
}

export default Homework3