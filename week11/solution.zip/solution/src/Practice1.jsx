import React from 'react'

class Practice1 extends React.Component {
  constructor(props) {
    super(props)

    this.state = {
      countClicked: 0
    }
  }

  decrement = () => {
    this.setState(prevState => {
      return {
        ...prevState,
        countClicked: prevState.countClicked - 1
      }
    })
  }

  increment = () => {
    this.setState(prevState => {
      return {
        ...prevState,
        countClicked: prevState.countClicked + 1
      }
    })
  }

  render() {
    return (
      <>
        <p><button onClick={this.decrement}>Decrement</button></p>
        <p><span>{this.state.countClicked}</span></p>
        <p><button onClick={this.increment}>Increment</button></p>
      </>
    )
  }
}

export default Practice1