import React from "react";

class Practice3 extends React.Component {
  constructor(props) {
    super(props)

    this.state = {
      componentShown: true
    }
  }

  deleteComponent = () => {
    this.setState({
      componentShown: false
    })
  }

  render() {
    return (
      <>
        {this.state.componentShown && <Hello display={this.state.componentShown} deleteComponent={this.deleteComponent} />}
      </>
    )
  }
}

class Hello extends React.Component {

  componentWillUnmount() {
    alert('Unmounting')
  }

  render() {
    return (
      <>
        {this.props.display &&
          <>
            <div>Hello</div>
            <button onClick={this.props.deleteComponent}>Delete Component</button>
          </>
        }
      </>
    )
  }
}

export default Practice3