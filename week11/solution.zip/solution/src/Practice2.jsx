import React from 'react'

class Practice1 extends React.Component {
  constructor(props) {
    super(props)

    this.state = {
      backgroundColor: 'blue'
    }
  }

  componentDidMount() {
    setTimeout(() => {
      this.setState({
        backgroundColor: 'red'
      })
    }, 5000)
  }

  render() {
    const backgroundColor = this.state.backgroundColor
    return (
      <>
        <div style={{ backgroundColor, width: 300, height: 300 }}></div>
      </>
    )
  }
}

export default Practice1